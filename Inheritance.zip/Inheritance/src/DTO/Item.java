package DTO;

import java.util.*;

public class Item {
    protected int value;
    protected String creator;

    public Item() {
    }

    public Item(int value, String creator) {
        this.value = value;
        this.creator = creator;
    }
    
    private static final Scanner sc = new Scanner(System.in);
    
    public int getValue() {
        return value;
    }

    public String getCreator() {
        return creator;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    @Override
    public String toString() {
        return "Item{" + "value=" + value + ", creator=" + creator + '}';
    }

    public void output() {
        System.out.println("Value: " + this.value);
        System.out.println("Creator: " + this.creator);
    }

    public int checkInputIntLimit(int min, int max) {
        if (min > max) {
            int temp = min;
            min = max;
            max = temp;
        }

        int value = Integer.MIN_VALUE;

        while (true) {
            try {
                value = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.err.println("Please enter again");
            }

            if (value >= min && value <= max) {
                break;
            }
        }

        return value;
    }
    
    public boolean getBoolean() {
        boolean value = false;
        
        while (true) {
            try {
                value = Boolean.parseBoolean(sc.nextLine());
                break;
            } catch (NumberFormatException e) {
                System.err.println("Please enter again");
            }
        }
        
        return value;
    }
    public void input() {

        System.out.println("Enter value: ");
        this.value = checkInputIntLimit(0, Integer.MAX_VALUE);

        System.out.println("Enter creator: ");
        this.creator = sc.nextLine();
    }
}
